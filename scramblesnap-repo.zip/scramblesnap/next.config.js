// next.config.js — ScrambleSnap production config
const withPWA = require('next-pwa')({
  dest: 'public',
  register: true,
  skipWaiting: true,
  disable: process.env.NODE_ENV === 'development',
  runtimeCaching: [
    {
      urlPattern: /^https:\/\/scramblesnap\.com\/api\/.*/,
      handler: 'NetworkFirst',
      options: { cacheName: 'api-cache', expiration: { maxEntries: 50, maxAgeSeconds: 60 * 60 } }
    },
    {
      urlPattern: /\.(?:js|css|woff2?)$/,
      handler: 'CacheFirst',
      options: { cacheName: 'static-cache', expiration: { maxAgeSeconds: 60 * 60 * 24 * 30 } }
    }
  ]
});

/** @type {import('next').NextConfig} */
const config = {
  // Performance
  compress: true,
  poweredByHeader: false,
  reactStrictMode: true,

  // Image optimization
  images: {
    formats: ['image/avif', 'image/webp'],
    deviceSizes: [640, 750, 828, 1080, 1200],
  },

  // SEO: trailing slash consistency
  trailingSlash: false,

  // Headers for SEO & security
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-DNS-Prefetch-Control', value: 'on' },
          { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
        ],
      },
      {
        source: '/static/:path*',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
        ],
      },
    ];
  },

  // Redirects for SEO (handle common typos/aliases)
  async redirects() {
    return [
      { source: '/word-unscrambler', destination: '/', permanent: true },
      { source: '/anagram-solver', destination: '/', permanent: true },
      { source: '/scrabble', destination: '/scrabble-solver', permanent: true },
      { source: '/wordle', destination: '/wordle-helper', permanent: true },
      { source: '/wwf', destination: '/words-with-friends', permanent: true },
    ];
  },
};

module.exports = withPWA(config);
