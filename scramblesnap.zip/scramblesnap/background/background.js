// ScrambleSnap Background Service Worker (MV3)

let overlayActiveTabId = null;

// Handle keyboard shortcut to toggle overlay
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'toggle-overlay') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    // Check Pro status
    const { pro } = await chrome.storage.sync.get('pro');
    if (!pro) {
      // Open popup to upsell
      chrome.action.openPopup();
      return;
    }

    try {
      // Inject content script if not already present
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['dictionary/words.js', 'content/overlay.js']
      });
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: ['content/overlay.css']
      });

      // Toggle overlay
      chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_OVERLAY' });
    } catch (e) {
      console.error('ScrambleSnap overlay inject error:', e);
    }
  }
});

// Handle messages from popup/content
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'CHECK_PRO') {
    chrome.storage.sync.get(['pro', 'licenseKey', 'email'], (data) => {
      sendResponse({ pro: !!data.pro, licenseKey: data.licenseKey, email: data.email });
    });
    return true;
  }

  if (msg.type === 'ACTIVATE_PRO') {
    chrome.storage.sync.set({
      pro: true,
      licenseKey: msg.licenseKey,
      email: msg.email,
      proActivatedAt: Date.now()
    }, () => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (msg.type === 'INCREMENT_SOLVES') {
    chrome.storage.local.get(['solveCount', 'sessionCount'], (data) => {
      const solveCount = (data.solveCount || 0) + 1;
      chrome.storage.local.set({ solveCount });
      sendResponse({ solveCount, sessionCount: data.sessionCount || 1 });
    });
    return true;
  }

  if (msg.type === 'OPEN_OVERLAY') {
    // Re-inject overlay on active tab
    chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
      if (!tab?.id) return;
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['dictionary/words.js', 'content/overlay.js']
        });
        await chrome.scripting.insertCSS({
          target: { tabId: tab.id },
          files: ['content/overlay.css']
        });
        chrome.tabs.sendMessage(tab.id, { type: 'SHOW_OVERLAY', letters: msg.letters });
      } catch (e) {}
    });
    return true;
  }
});

// Track sessions
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get('sessionCount', (data) => {
    chrome.storage.local.set({ sessionCount: (data.sessionCount || 0) + 1 });
  });
});

// On install: set first run flag
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.storage.local.set({
      firstRun: true,
      installDate: Date.now(),
      solveCount: 0,
      sessionCount: 1
    });
  }
});
