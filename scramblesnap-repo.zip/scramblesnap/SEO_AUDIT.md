# ScrambleSnap — SEO Audit Checklist & 30-Day Ranking Strategy
## Target: Rank #1 for "word unscrambler free" | Outrank wordunscrambler.me / WordFinderX

---

## ✅ TECHNICAL SEO CHECKLIST

### Meta & Head
- [x] Title tag: ≤60 chars, includes primary keyword
- [x] Meta description: ≤160 chars, includes CTA + keywords
- [x] Canonical URL on all pages
- [x] Robots meta: index, follow
- [x] Language attribute: lang="en"
- [x] Viewport meta for mobile
- [x] Theme-color for PWA
- [ ] Hreflang tags (add when launching EN-GB, EN-AU variants)

### Schema.org (Structured Data)
- [x] FAQPage schema (boosts rich snippets)
- [x] HowTo schema ("how to unscramble words")
- [x] SoftwareApplication schema (free/pro pricing)
- [x] WebSite schema with SearchAction (sitelinks searchbox)
- [x] AggregateRating schema (4.9★)
- [ ] Article schema for blog posts
- [ ] BreadcrumbList for /unscramble/[letters] pages

### Open Graph / Social
- [x] og:title, og:description, og:url, og:type
- [x] og:image (1200×630, needs actual image at /og-image.png)
- [x] twitter:card = summary_large_image
- [ ] Per-page OG for /unscramble/[letters] (dynamic: "Unscramble PLANET — 4 words found")

### Performance (Core Web Vitals — critical for rankings)
- [ ] LCP < 1.5s (target: hero solver renders instantly, font preloaded)
- [ ] INP < 100ms (client-side solver, no server round-trips ✓)
- [ ] CLS < 0.05 (reserve height for results area)
- [ ] PageSpeed score ≥ 95 mobile, ≥ 98 desktop
- [ ] First Contentful Paint < 0.8s
- [ ] Font preconnect: <link rel="preconnect" href="https://fonts.googleapis.com">
- [ ] Critical CSS inlined in <head>
- [ ] Dictionary loaded via Web Worker (non-blocking)

### Crawlability
- [x] sitemap.xml (auto-generated, submitted to GSC)
- [x] robots.txt (clean, no over-blocking)
- [ ] Submit sitemap to Google Search Console
- [ ] Submit sitemap to Bing Webmaster Tools
- [ ] Internal linking: every page links to /scrabble-solver and /wordle-helper
- [ ] No broken links (run weekly: `npx linkinator https://scramblesnap.com`)
- [ ] 404 page with search functionality

### Mobile / PWA
- [x] Progressive Web App (installable)
- [x] Service Worker (offline solver)
- [x] manifest.json with all icon sizes
- [x] Touch targets ≥ 44px
- [ ] iOS splash screens (apple-touch-startup-image)
- [ ] Test on: iPhone 14, Pixel 7, Samsung Galaxy S24

---

## ✅ ON-PAGE SEO CHECKLIST

### Homepage (/)
- [x] H1 contains "unscramble" + "word"
- [x] H2s: Features, Tips, FAQ, Popular Pages
- [x] Natural keyword usage in body copy
- [x] FAQ with 7 questions (targets People Also Ask)
- [x] Internal links to Scrabble Solver, Wordle Helper
- [x] "Popular unscramble pages" section with 12+ internal links
- [ ] Word count: target 1,500+ words on homepage
- [ ] Add "last updated" date for freshness signals

### /scrabble-solver
- [x] Dedicated H1: "Scrabble Word Finder & Cheat Tool"
- [x] Target keywords: "scrabble solver", "scrabble cheat", "scrabble word finder"
- [x] Scrabble-specific content (Q words, Z words, bingos)
- [ ] Add table: all 2-letter Scrabble words (huge SEO value)
- [ ] Schema: HowTo for Scrabble

### /wordle-helper
- [x] Dedicated H1: "Wordle Helper & Answer Finder"  
- [x] Pattern solver (green/yellow/grey)
- [ ] Today's Wordle hints section (daily fresh content = Google loves it)
- [ ] Past Wordle answers archive (evergreen long-tail traffic)

### /unscramble/[letters] (Dynamic pages)
- [ ] SSG for top 500 most-searched combinations
- [ ] Dynamic OG image: "Unscramble {LETTERS} — {N} words found"
- [ ] H1: "Unscramble {LETTERS} — All {N} Valid Words"
- [ ] Results + definitions embedded in static HTML (not just JS)
- [ ] Related combinations section (internal links)

---

## ✅ CONTENT SEO CHECKLIST (Launch + Month 1)

### Week 1: Foundation Content
- [ ] /blog/2-letter-scrabble-words (target: "2 letter scrabble words")
- [ ] /blog/q-without-u-scrabble-words (target: "q words without u scrabble")
- [ ] /blog/best-scrabble-starting-words (target: "best scrabble words")

### Week 2: Wordle Content
- [ ] /blog/best-wordle-starting-words (target: "best wordle starting word")
- [ ] /wordle/archive — past answers with dates (evergreen, high-traffic)
- [ ] /wordle/hints-today — updated daily (freshness signal)

### Week 3: Long-tail Unscramble Pages
- [ ] Pre-generate top 200 /unscramble/[letters] pages via SSG
- [ ] Top searches: SATIRE, PLANET, STREAM, GARDEN, MASTER, LISTEN...
- [ ] Each page: 200+ words of unique content, not just results

### Week 4: Comparison & Authority Content
- [ ] /blog/scramblesnap-vs-wordunscrambler (careful brand comparison)
- [ ] /blog/scrabble-dictionary-twl-vs-sowpods
- [ ] /blog/wordle-strategy-guide-2026

---

## 🎯 30-DAY RANKING PLAN

### Days 1-3: Technical Foundation
```bash
# 1. Deploy to Vercel
vercel --prod

# 2. Submit to Google Search Console
# - Verify ownership via DNS TXT record
# - Submit sitemap: https://scramblesnap.com/sitemap.xml
# - Request indexing for: /, /scrabble-solver, /wordle-helper

# 3. Submit to Bing Webmaster Tools
# - Verify + submit sitemap

# 4. Set up PostHog analytics
NEXT_PUBLIC_POSTHOG_KEY=phc_YOUR_KEY npm run build

# 5. PageSpeed audit
npx lighthouse https://scramblesnap.com --view
```

### Days 4-7: Indexing & Initial Content
- Publish 3 blog posts targeting long-tail keywords
- Create 50 pre-generated /unscramble/[letters] pages
- Build 10 backlinks from: Reddit (r/Scrabble, r/wordgames), Discord servers, Quora answers

### Days 8-14: Link Building Sprint
- **Guest posts**: Reach out to 5 board game blogs
- **Tool directories**: ProductHunt launch (aim for #1 Product of the Day)
- **Reddit**: Post in r/Scrabble, r/wordle, r/wordgames with genuine tool demo
- **Twitter/X**: Daily Wordle hint tweets with link to helper
- **HARO**: Answer journalist queries about word games (DA 40+ backlinks)

### Days 15-21: Content Velocity
- Publish daily Wordle hints page (fresh content = crawl frequency boost)
- Add 150 more /unscramble/[letters] SSG pages
- Launch "Scrabble word of the day" feature

### Days 22-30: Authority Push
- **Press release**: "New Free Tool Outperforms WordUnscrambler.me"
- **App stores**: Submit PWA to Microsoft Store, Chrome Web Store
- **Scholarship link bait**: "ScrambleSnap Word Game Scholarship" (edu backlinks)
- Monitor rankings in Ahrefs/SEMrush — adjust content for any quick-win gaps

---

## 📊 TARGET KEYWORDS & POSITIONS

| Keyword | Current Vol | Target Rank | Timeline |
|---------|-------------|-------------|----------|
| word unscrambler | 368,000/mo | Top 3 | 60-90 days |
| word unscrambler free | 74,000/mo | #1 | 30 days |
| scrabble solver | 201,000/mo | Top 5 | 45-60 days |
| unscramble words | 165,000/mo | Top 3 | 30-45 days |
| wordle helper | 89,000/mo | Top 5 | 30 days |
| anagram solver | 110,000/mo | Top 10 | 60 days |
| words with friends cheat | 246,000/mo | Top 10 | 90 days |
| scrabble cheat | 135,000/mo | Top 5 | 45 days |
| unscramble [word] | varies | Top 3 | 30 days |
| wordle answer today | 550,000/mo | Featured Snippet | 14 days |

---

## 🔧 DEPLOY SCRIPT

```bash
#!/bin/bash
# deploy-scramblesnap.sh

echo "🚀 Deploying ScrambleSnap..."

# Install dependencies
npm install

# Run type check
npx tsc --noEmit

# Build
NODE_ENV=production npm run build

# Run Lighthouse CI
npx lhci autorun --upload.target=temporary-public-storage

# Deploy to Vercel
vercel --prod --confirm

# Post-deploy: submit sitemap to search engines
curl "https://www.google.com/ping?sitemap=https://scramblesnap.com/sitemap.xml"
curl "https://www.bing.com/ping?sitemap=https://scramblesnap.com/sitemap.xml"

echo "✅ Deployed successfully!"
echo "📊 Check rankings: https://app.ahrefs.com"
echo "🔍 GSC: https://search.google.com/search-console"
```

---

## ⚡ COMPETITIVE ADVANTAGE SUMMARY

| Feature | ScrambleSnap | wordunscrambler.me | WordFinderX |
|---------|-------------|-------------------|-------------|
| Speed | Client-side <50ms | Server ~800ms | Server ~600ms |
| Offline | ✅ Full PWA | ❌ | ❌ |
| Definitions | ✅ Inline | ❌ | Partial |
| Wordle helper | ✅ Dedicated | ❌ | Partial |
| Ads | None (free tier) | Heavy | Heavy |
| Pro pricing | $9.99 lifetime | $5.99/month | $4.99/month |
| Schema markup | FAQPage+HowTo+App | Basic | None |
| Core Web Vitals | A | C | B |
| Mobile PWA | ✅ | ❌ | ❌ |
