// ScrambleSnap Popup JS – all events wired via addEventListener (CSP-safe)

const STRIPE_PAYMENT_LINK = 'https://buy.stripe.com/REPLACE_WITH_YOUR_PAYMENT_LINK';
const WEBSTORE_URL = 'https://chrome.google.com/webstore/detail/REPLACE_WITH_YOUR_EXTENSION_ID';

let currentMode    = 'scrabble';
let currentSort    = 'score';
let currentResults = [];
let isPro          = false;
let favorites      = new Set();
let solveHistory   = [];
let onboardStep    = 1;
const TOTAL_STEPS  = 5;

// ── INIT ────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  const data = await storageGet(['firstRun', 'pro', 'favs', 'solveHistory']);
  isPro = !!data.pro;
  if (data.favs) favorites = new Set(data.favs);
  if (data.solveHistory) solveHistory = data.solveHistory;

  // Mac modifier key
  if (navigator.platform.toLowerCase().includes('mac')) {
    const mk = document.getElementById('modifier-key');
    if (mk) mk.textContent = 'Cmd';
  }

  if (data.firstRun !== false) {
    showOnboarding();
  } else {
    showApp();
  }

  wireOnboarding();
  wireApp();
  setupWordleCells();
  checkReviewPrompt();
});

// ── STORAGE ─────────────────────────────────────────────────────────────────
function storageGet(keys) {
  return new Promise(r => chrome.storage.sync.get(keys, r));
}
function storageSet(obj) {
  return new Promise(r => chrome.storage.sync.set(obj, r));
}

// ── ONBOARDING WIRING ───────────────────────────────────────────────────────
function wireOnboarding() {
  document.getElementById('btn-step1').addEventListener('click', nextStep);
  document.getElementById('btn-step2').addEventListener('click', nextStep);
  document.getElementById('btn-step3').addEventListener('click', nextStep);
  document.getElementById('btn-step4').addEventListener('click', nextStep);
  document.getElementById('btn-stripe-onboard').addEventListener('click', openStripe);
  document.getElementById('btn-start-free').addEventListener('click', finishOnboarding);

  document.querySelectorAll('.game-check').forEach(el => {
    el.addEventListener('click', () => el.classList.toggle('selected'));
  });
}

function showOnboarding() {
  document.getElementById('onboarding').style.display = 'flex';
  document.getElementById('app').style.display = 'none';
  renderDots();
}

function nextStep() {
  document.getElementById('step-' + onboardStep)?.classList.remove('active');
  onboardStep++;
  const next = document.getElementById('step-' + onboardStep);
  if (next) {
    next.classList.add('active');
    renderDots();
    if (onboardStep === 3) runDemo();
  }
}

function renderDots() {
  ['onboard-dots', 'onboard-dots2'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = Array.from({ length: TOTAL_STEPS }, (_, i) =>
      '<div class="onboard-dot' + (i + 1 === onboardStep ? ' active' : '') + '"></div>'
    ).join('');
  });
}

function runDemo() {
  const wordEl    = document.getElementById('demo-word');
  const lettersEl = document.getElementById('demo-letters');
  if (!wordEl || !lettersEl) return;
  setTimeout(() => { lettersEl.style.transition = 'color .4s'; lettersEl.style.color = '#00E676'; }, 500);
  setTimeout(() => {
    wordEl.style.transition = 'all .4s';
    wordEl.style.opacity = '1';
    wordEl.style.transform = 'scale(1.1)';
    setTimeout(() => { wordEl.style.transform = 'scale(1)'; }, 300);
    launchConfetti(5);
  }, 1200);
}

async function finishOnboarding() {
  const selectedGames = [...document.querySelectorAll('.game-check.selected')].map(el => el.dataset.game);
  await storageSet({ firstRun: false, selectedGames });
  showApp();
}

// ── APP WIRING ──────────────────────────────────────────────────────────────
function wireApp() {
  // Header
  document.getElementById('settings-btn').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
  document.getElementById('history-btn').addEventListener('click', openHistoryModal);

  // Solve
  document.getElementById('solve-btn').addEventListener('click', solve);
  document.getElementById('letters-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') solve();
  });

  // Game mode buttons
  document.querySelectorAll('.game-btn').forEach(btn => {
    btn.addEventListener('click', () => setMode(btn));
  });

  // Sort buttons
  document.querySelectorAll('.sort-btn').forEach(btn => {
    btn.addEventListener('click', () => setSort(btn));
  });

  // Footer
  document.getElementById('footer-upgrade-link').addEventListener('click', () => openModal('upgrade-modal'));
  document.getElementById('footer-upgrade').addEventListener('click', () => openModal('upgrade-modal'));
  document.getElementById('feedback-btn').addEventListener('click', shareFeedback);

  // Upgrade modal
  document.getElementById('close-upgrade-modal').addEventListener('click', () => closeModal('upgrade-modal'));
  document.getElementById('close-upgrade-modal-2').addEventListener('click', () => closeModal('upgrade-modal'));
  document.getElementById('btn-stripe-modal').addEventListener('click', openStripe);

  // History modal
  document.getElementById('close-history-modal').addEventListener('click', () => closeModal('history-modal'));
  document.getElementById('close-history-modal-2').addEventListener('click', () => closeModal('history-modal'));

  // Review
  document.getElementById('review-yes-btn').addEventListener('click', openReview);
  document.getElementById('review-no-btn').addEventListener('click', dismissReview);

  // Close modals on backdrop click
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) closeModal(overlay.id);
    });
  });
}

function showApp() {
  document.getElementById('onboarding').style.display = 'none';
  document.getElementById('app').style.display = 'flex';
  updateProUI();
}

function updateProUI() {
  const badge      = document.getElementById('tier-badge');
  const footerUpg  = document.getElementById('footer-upgrade');
  const filtersRow = document.getElementById('filters-row');
  if (isPro) {
    badge.textContent = 'PRO';
    badge.className = 'pro-badge';
    if (footerUpg) footerUpg.style.display = 'none';
    filtersRow.classList.add('visible');
  } else {
    badge.textContent = 'FREE';
    badge.className = 'free-badge';
    if (footerUpg) footerUpg.style.display = 'block';
    filtersRow.classList.remove('visible');
  }
}

// ── GAME MODE ───────────────────────────────────────────────────────────────
function setMode(btn) {
  document.querySelectorAll('.game-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  currentMode = btn.dataset.mode;
  const wordleSec = document.getElementById('wordle-section');
  if (currentMode === 'wordle') {
    wordleSec.classList.add('visible');
  } else {
    wordleSec.classList.remove('visible');
  }
  if (currentResults.length) solve();
}

// ── SORT ────────────────────────────────────────────────────────────────────
function setSort(btn) {
  document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  currentSort = btn.dataset.sort;
  renderResults(currentResults);
}

// ── WORDLE CELLS ────────────────────────────────────────────────────────────
function setupWordleCells() {
  const cells = document.querySelectorAll('.wordle-cell');
  cells.forEach((cell, i) => {
    cell.addEventListener('click', () => {
      if (cell.classList.contains('green')) {
        cell.classList.replace('green', 'yellow');
      } else if (cell.classList.contains('yellow')) {
        cell.classList.remove('yellow');
      } else {
        cell.classList.add('green');
      }
    });
    cell.addEventListener('input', () => {
      cell.value = cell.value.toUpperCase();
      if (cell.value && i < cells.length - 1) cells[i + 1].focus();
    });
    cell.addEventListener('keydown', e => {
      if (e.key === 'Backspace' && !cell.value && i > 0) cells[i - 1].focus();
    });
  });
}

function getWordlePattern() {
  const cells = document.querySelectorAll('.wordle-cell');
  const greens = {}, yellows = {};
  cells.forEach((c, i) => {
    if (!c.value) return;
    const letter = c.value.toLowerCase();
    if (c.classList.contains('green')) {
      greens[i] = letter;
    } else if (c.classList.contains('yellow')) {
      if (!yellows[letter]) yellows[letter] = [];
      yellows[letter].push(i);
    }
  });
  return (Object.keys(greens).length || Object.keys(yellows).length) ? { greens, yellows } : null;
}

// ── SOLVE ───────────────────────────────────────────────────────────────────
async function solve() {
  const input = document.getElementById('letters-input');
  const letters = input?.value?.trim();
  if (!letters) { showToast('Enter some letters first!'); input?.focus(); return; }

  const btn = document.getElementById('solve-btn');
  btn.classList.add('loading');
  await new Promise(r => setTimeout(r, 150));

  try {
    const options = {
      game: currentMode === 'wwf' ? 'wwf' : 'scrabble',
      minLength: isPro ? parseInt(document.getElementById('f-minlen')?.value || 2) : 2,
      startsWith: isPro ? (document.getElementById('f-starts')?.value || '') : '',
      endsWith:   isPro ? (document.getElementById('f-ends')?.value || '') : '',
      mustContain: isPro ? (document.getElementById('f-contains')?.value || '') : '',
      noRepeats:  isPro ? document.getElementById('f-norepeats')?.checked : false,
      wordlePattern: currentMode === 'wordle' ? getWordlePattern() : null,
    };

    const results = unscramble(letters, options);
    currentResults = results;
    renderResults(results);

    addToHistory({ letters, count: results.length, mode: currentMode });
    incrementSolves();

    if (results.length > 0 && results[0].score >= 15) launchConfetti(10);
  } catch (err) {
    console.error('Solve error:', err);
    showToast('Error solving – please try again');
  } finally {
    btn.classList.remove('loading');
  }
}

// ── RENDER RESULTS ──────────────────────────────────────────────────────────
function renderResults(results) {
  const container = document.getElementById('results-list');
  const meta      = document.getElementById('results-meta');
  const countEl   = document.getElementById('result-count');

  if (!results || results.length === 0) {
    container.innerHTML = '<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-title">No words found</div><div class="empty-sub">Try adding a wildcard (?) or removing filters</div></div>';
    meta.style.display = 'none';
    return;
  }

  const sorted = [...results];
  if (currentSort === 'length') sorted.sort((a, b) => b.length - a.length || b.score - a.score);
  else if (currentSort === 'alpha') sorted.sort((a, b) => a.word.localeCompare(b.word));

  meta.style.display = 'flex';
  countEl.textContent = sorted.length;

  // Build DOM elements instead of innerHTML with handlers
  container.innerHTML = '';
  sorted.forEach((r, i) => {
    const isBest = i === 0 && currentSort === 'score';
    const isFav  = favorites.has(r.word);

    const item = document.createElement('div');
    item.className = 'word-item' + (isBest ? ' best' : '') + (isFav ? ' favorited' : '');
    item.style.animationDelay = Math.min(i * 0.03, 0.5) + 's';
    item.dataset.word = r.word;

    const left = document.createElement('div');
    left.style.cssText = 'display:flex;align-items:center;gap:8px';

    const wordText = document.createElement('div');
    wordText.className = 'word-text';
    wordText.textContent = r.word.toUpperCase();
    left.appendChild(wordText);

    if (isBest) {
      const badge = document.createElement('span');
      badge.style.cssText = 'font-size:10px;background:var(--teal);color:#000;padding:1px 6px;border-radius:4px;font-weight:700';
      badge.textContent = 'BEST';
      left.appendChild(badge);
    }

    const right = document.createElement('div');
    right.style.cssText = 'display:flex;align-items:center;gap:8px';

    const lenEl = document.createElement('span');
    lenEl.className = 'word-len';
    lenEl.textContent = r.length + 'L';

    const scoreEl = document.createElement('span');
    scoreEl.className = 'word-score';
    scoreEl.textContent = r.score + 'pts';

    const actions = document.createElement('div');
    actions.className = 'word-actions';

    if (isPro) {
      const favBtn = document.createElement('button');
      favBtn.className = 'word-action-btn';
      favBtn.textContent = isFav ? '⭐' : '☆';
      favBtn.addEventListener('click', e => { e.stopPropagation(); toggleFav(r.word); });
      actions.appendChild(favBtn);

      const shareBtn = document.createElement('button');
      shareBtn.className = 'word-action-btn';
      shareBtn.textContent = '📤';
      shareBtn.addEventListener('click', e => { e.stopPropagation(); shareWord(r.word); });
      actions.appendChild(shareBtn);
    }

    const copyBtn = document.createElement('button');
    copyBtn.className = 'word-action-btn';
    copyBtn.textContent = '⎘';
    copyBtn.title = 'Copy';
    copyBtn.addEventListener('click', e => { e.stopPropagation(); copyWord(r.word); });
    actions.appendChild(copyBtn);

    right.appendChild(lenEl);
    right.appendChild(scoreEl);
    right.appendChild(actions);

    item.appendChild(left);
    item.appendChild(right);
    item.addEventListener('click', () => copyWord(r.word));
    container.appendChild(item);
  });
}

// ── COPY & SHARE ─────────────────────────────────────────────────────────────
async function copyWord(word) {
  try {
    await navigator.clipboard.writeText(word.toUpperCase());
  } catch {
    const ta = document.createElement('textarea');
    ta.value = word.toUpperCase();
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
  }
  showToast('Copied ' + word.toUpperCase() + '!');
}

function shareWord(word) {
  const letters = document.getElementById('letters-input')?.value?.toUpperCase() || '???';
  const text = 'Solved "' + word.toUpperCase() + '" from "' + letters + '" with ScrambleSnap!\nhttps://chrome.google.com/webstore/detail/scramblesnap';
  navigator.clipboard.writeText(text);
  showToast('Share text copied!');
}

// ── FAVORITES ────────────────────────────────────────────────────────────────
async function toggleFav(word) {
  if (favorites.has(word)) { favorites.delete(word); showToast('Removed from favorites'); }
  else { favorites.add(word); showToast('⭐ Added to favorites'); }
  await storageSet({ favs: [...favorites] });
  renderResults(currentResults);
}

// ── HISTORY ──────────────────────────────────────────────────────────────────
async function addToHistory(entry) {
  solveHistory.unshift({ ...entry, at: Date.now() });
  solveHistory = solveHistory.slice(0, 50);
  await storageSet({ solveHistory });
}

function openHistoryModal() {
  const list = document.getElementById('history-list');
  if (!solveHistory.length) {
    list.innerHTML = '<div style="color:var(--text-dim);font-size:13px;text-align:center;padding:20px">No solves yet</div>';
  } else {
    list.innerHTML = solveHistory.slice(0, 20).map(h =>
      '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border)">' +
      '<span style="font-family:Courier New,monospace;font-size:14px;font-weight:700">' + h.letters.toUpperCase() + '</span>' +
      '<span style="font-size:12px;color:var(--text-dim)">' + h.count + ' words · ' + h.mode + '</span>' +
      '</div>'
    ).join('');
  }
  openModal('history-modal');
}

// ── SOLVE COUNT ──────────────────────────────────────────────────────────────
function incrementSolves() {
  chrome.runtime.sendMessage({ type: 'INCREMENT_SOLVES' });
}

async function checkReviewPrompt() {
  const data = await new Promise(r => chrome.storage.local.get(['solveCount', 'sessionCount', 'reviewDismissed'], r));
  if (!data.reviewDismissed && (data.solveCount >= 5 || data.sessionCount >= 3)) {
    document.getElementById('review-banner').classList.add('visible');
  }
}

function openReview() {
  chrome.tabs.create({ url: WEBSTORE_URL });
  chrome.storage.local.set({ reviewDismissed: true });
  document.getElementById('review-banner').classList.remove('visible');
}

function dismissReview() {
  chrome.storage.local.set({ reviewDismissed: true });
  document.getElementById('review-banner').classList.remove('visible');
}

// ── STRIPE ───────────────────────────────────────────────────────────────────
function openStripe() {
  const successUrl = chrome.runtime.getURL('options/options.html') + '?pro_success=1';
  chrome.tabs.create({ url: STRIPE_PAYMENT_LINK + '?success_url=' + encodeURIComponent(successUrl) });
  closeModal('upgrade-modal');
  showToast('Opening secure checkout...');
}

// ── MODALS ───────────────────────────────────────────────────────────────────
function openModal(id) { document.getElementById(id)?.classList.add('visible'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('visible'); }

// ── FEEDBACK ─────────────────────────────────────────────────────────────────
function shareFeedback() {
  chrome.tabs.create({ url: 'mailto:hello@scramblesnap.io?subject=ScrambleSnap Feedback' });
}

// ── TOAST ─────────────────────────────────────────────────────────────────────
let toastTimeout;
function showToast(msg) {
  let toast = document.getElementById('ss-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'ss-toast';
    toast.style.cssText = 'position:fixed;bottom:56px;left:50%;transform:translateX(-50%);' +
      'background:rgba(30,30,46,0.95);border:1px solid rgba(0,212,255,0.3);' +
      'color:#fff;font-family:system-ui,sans-serif;font-size:13px;font-weight:600;' +
      'padding:8px 16px;border-radius:8px;z-index:999;white-space:nowrap;' +
      'backdrop-filter:blur(8px);transition:opacity .2s;box-shadow:0 4px 16px rgba(0,0,0,0.4)';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.opacity = '1';
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => { toast.style.opacity = '0'; }, 2000);
}

// ── CONFETTI ──────────────────────────────────────────────────────────────────
function launchConfetti(count) {
  const canvas = document.getElementById('confetti-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  canvas.width  = canvas.offsetWidth  || 380;
  canvas.height = canvas.offsetHeight || 600;
  const colors = ['#00D4FF', '#FFB830', '#00E676', '#FF4444', '#A855F7'];
  const particles = Array.from({ length: count }, () => ({
    x: Math.random() * canvas.width, y: canvas.height * 0.3,
    vx: (Math.random() - 0.5) * 4, vy: -Math.random() * 6 - 2,
    color: colors[Math.floor(Math.random() * colors.length)],
    size: Math.random() * 6 + 3, rot: Math.random() * 360,
    rotV: (Math.random() - 0.5) * 10, life: 1
  }));
  function frame() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    let alive = false;
    for (const p of particles) {
      p.x += p.vx; p.y += p.vy; p.vy += 0.2; p.rot += p.rotV; p.life -= 0.02;
      if (p.life <= 0) continue;
      alive = true;
      ctx.save(); ctx.globalAlpha = p.life; ctx.fillStyle = p.color;
      ctx.translate(p.x, p.y); ctx.rotate(p.rot * Math.PI / 180);
      ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
      ctx.restore();
    }
    if (alive) requestAnimationFrame(frame);
    else ctx.clearRect(0, 0, canvas.width, canvas.height);
  }
  requestAnimationFrame(frame);
}
