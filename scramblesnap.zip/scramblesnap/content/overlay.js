// ScrambleSnap Content Script – Floating Overlay
// Injected into host pages via background.js on Ctrl/Cmd+Shift+S

(function () {
  'use strict';

  const OVERLAY_ID = 'scramblesnap-overlay';
  let overlayEl = null;
  let dragState  = null;
  let mode       = 'scrabble';
  let lastResults = [];

  // ── MESSAGE HANDLER ──────────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'TOGGLE_OVERLAY') {
      toggleOverlay();
    } else if (msg.type === 'SHOW_OVERLAY') {
      showOverlay(msg.letters || '');
    }
  });

  function toggleOverlay() {
    if (!overlayEl) {
      createOverlay();
    } else if (overlayEl.classList.contains('ss-hidden')) {
      overlayEl.classList.remove('ss-hidden');
      overlayEl.querySelector('.ss-input')?.focus();
    } else {
      overlayEl.classList.add('ss-hidden');
    }
  }

  function showOverlay(prefill = '') {
    if (!overlayEl) createOverlay();
    overlayEl.classList.remove('ss-hidden');
    const input = overlayEl.querySelector('.ss-input');
    if (input) {
      input.value = prefill.toUpperCase();
      input.focus();
      if (prefill) solveFromOverlay();
    }
  }

  // ── CREATE OVERLAY ───────────────────────────
  function createOverlay() {
    // Remove any stale instance
    document.getElementById(OVERLAY_ID)?.remove();

    overlayEl = document.createElement('div');
    overlayEl.id = OVERLAY_ID;
    overlayEl.innerHTML = `
      <div class="ss-header" id="ss-drag-handle">
        <div class="ss-logo">
          <div class="ss-logo-icon">⚡</div>
          Scramble<span class="ss-snap">Snap</span>
        </div>
        <button class="ss-close" title="Close (Ctrl+Shift+S)">✕</button>
      </div>

      <div class="ss-input-row">
        <input
          class="ss-input" type="text"
          placeholder="Enter letters…"
          maxlength="20" spellcheck="false" autocomplete="off"
        >
        <button class="ss-solve-btn">⚡ Solve</button>
      </div>

      <div class="ss-results" id="ss-results-list">
        <div class="ss-empty">Enter letters and hit Solve</div>
      </div>

      <div class="ss-footer">
        <div class="ss-count">Ready</div>
        <select class="ss-mode-select">
          <option value="scrabble">🎯 Scrabble</option>
          <option value="wwf">📱 WWF</option>
          <option value="anagram">🔤 Anagram</option>
        </select>
      </div>
    `;

    document.body.appendChild(overlayEl);

    // Try to restore position
    const saved = JSON.parse(localStorage.getItem('ss-overlay-pos') || 'null');
    if (saved) {
      overlayEl.style.bottom = 'auto';
      overlayEl.style.right  = 'auto';
      overlayEl.style.top    = saved.top  + 'px';
      overlayEl.style.left   = saved.left + 'px';
    }

    // Bind events
    const closeBtn   = overlayEl.querySelector('.ss-close');
    const solveBtn   = overlayEl.querySelector('.ss-solve-btn');
    const input      = overlayEl.querySelector('.ss-input');
    const header     = overlayEl.querySelector('#ss-drag-handle');
    const modeSelect = overlayEl.querySelector('.ss-mode-select');

    closeBtn.addEventListener('click', () => overlayEl.classList.add('ss-hidden'));
    solveBtn.addEventListener('click', solveFromOverlay);
    input.addEventListener('keydown', e => { if (e.key === 'Enter') solveFromOverlay(); });
    modeSelect.addEventListener('change', e => { mode = e.target.value; });

    // Drag
    setupDrag(header);

    // Auto-detect clipboard/selection
    detectAndPrefill(input);

    input.focus();
  }

  // ── SOLVE ────────────────────────────────────
  async function solveFromOverlay() {
    const input   = overlayEl?.querySelector('.ss-input');
    const list    = overlayEl?.querySelector('#ss-results-list');
    const counter = overlayEl?.querySelector('.ss-count');
    if (!input || !list) return;

    const letters = input.value.trim();
    if (!letters) {
      list.innerHTML = '<div class="ss-empty">Enter letters first!</div>';
      return;
    }

    // Spinner
    list.innerHTML = '<div class="ss-empty" style="animation: pulse 1s infinite">Solving…</div>';

    await new Promise(r => setTimeout(r, 80));

    try {
      const results = unscramble(letters, { game: mode, minLength: 2 });
      lastResults = results;

      if (!results.length) {
        list.innerHTML = '<div class="ss-empty">No words found. Try a wildcard (?)</div>';
        counter.innerHTML = 'No results';
        return;
      }

      counter.innerHTML = `<strong>${results.length}</strong> words`;

      list.innerHTML = results.slice(0, 50).map((r, i) => `
        <div class="ss-word-row${i === 0 ? ' ss-best' : ''}"
             style="animation-delay:${Math.min(i*0.025, 0.4)}s"
             data-word="${r.word}">
          <span class="ss-word">${r.word.toUpperCase()}</span>
          <div class="ss-meta">
            <span class="ss-len">${r.length}L</span>
            <span class="ss-score">${r.score}pts</span>
            <button class="ss-copy">⎘</button>
          </div>
        </div>
      `).join('');

      // Copy on row click
      list.querySelectorAll('.ss-word-row').forEach(row => {
        row.addEventListener('click', () => {
          copyToClipboard(row.dataset.word.toUpperCase());
          flashCopied(row);
        });
        row.querySelector('.ss-copy')?.addEventListener('click', e => {
          e.stopPropagation();
          copyToClipboard(row.dataset.word.toUpperCase());
          flashCopied(row);
        });
      });

    } catch (err) {
      list.innerHTML = '<div class="ss-empty">Error – please try again</div>';
      console.error('ScrambleSnap solve error:', err);
    }
  }

  function flashCopied(row) {
    const orig = row.querySelector('.ss-copy')?.textContent;
    if (row.querySelector('.ss-copy')) row.querySelector('.ss-copy').textContent = '✓';
    row.style.borderColor = 'rgba(0, 230, 118, 0.5)';
    setTimeout(() => {
      if (row.querySelector('.ss-copy')) row.querySelector('.ss-copy').textContent = orig || '⎘';
      row.style.borderColor = '';
    }, 1200);
  }

  // ── CLIPBOARD DETECTION ──────────────────────
  async function detectAndPrefill(inputEl) {
    // Try reading clipboard (requires clipboardRead permission)
    try {
      const text = await navigator.clipboard.readText();
      const clean = text.replace(/[^a-zA-Z?]/g, '').slice(0, 20);
      if (clean.length >= 2 && clean.length <= 20) {
        inputEl.value = clean.toUpperCase();
        inputEl.select();
      }
    } catch {}

    // Also try selected text
    const sel = window.getSelection()?.toString()?.trim();
    if (sel) {
      const clean = sel.replace(/[^a-zA-Z?]/g, '').slice(0, 20);
      if (clean.length >= 2) {
        inputEl.value = clean.toUpperCase();
      }
    }
  }

  // ── DRAG TO REPOSITION ───────────────────────
  function setupDrag(handle) {
    handle.addEventListener('mousedown', onDragStart);
  }

  function onDragStart(e) {
    if (e.target.classList.contains('ss-close')) return;
    e.preventDefault();

    const rect = overlayEl.getBoundingClientRect();
    dragState = {
      startX: e.clientX,
      startY: e.clientY,
      startLeft: rect.left,
      startTop:  rect.top
    };

    overlayEl.style.bottom = 'auto';
    overlayEl.style.right  = 'auto';

    document.addEventListener('mousemove', onDragMove);
    document.addEventListener('mouseup', onDragEnd);
  }

  function onDragMove(e) {
    if (!dragState) return;
    const dx = e.clientX - dragState.startX;
    const dy = e.clientY - dragState.startY;
    const newLeft = Math.max(0, Math.min(window.innerWidth  - 340, dragState.startLeft + dx));
    const newTop  = Math.max(0, Math.min(window.innerHeight - 100, dragState.startTop  + dy));
    overlayEl.style.left = newLeft + 'px';
    overlayEl.style.top  = newTop  + 'px';
  }

  function onDragEnd() {
    if (overlayEl) {
      localStorage.setItem('ss-overlay-pos', JSON.stringify({
        left: parseInt(overlayEl.style.left),
        top:  parseInt(overlayEl.style.top)
      }));
    }
    dragState = null;
    document.removeEventListener('mousemove', onDragMove);
    document.removeEventListener('mouseup', onDragEnd);
  }

  // ── CLIPBOARD WRITE ──────────────────────────
  function copyToClipboard(text) {
    try {
      navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
    } catch {
      fallbackCopy(text);
    }
  }

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0';
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
  }

})();
