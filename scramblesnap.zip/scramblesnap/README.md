# ⚡ ScrambleSnap – Word Unscrambler & Solver Chrome Extension

> *Snap scrambles. Win games.*

**Keywords:** word unscrambler solver scrabble wordle helper anagram finder words with friends

---

## 🚀 Quick Install (Development)

### Prerequisites
- Google Chrome 88+ (Manifest V3 support)
- Node.js 18+ (optional, for build tooling)

### Steps
1. **Clone / unzip** this folder
2. Open Chrome → `chrome://extensions/`
3. Enable **Developer mode** (toggle top-right)
4. Click **"Load unpacked"**
5. Select the `scramblesnap/` folder
6. Pin the extension from the extensions menu
7. Click ⚡ to open ScrambleSnap!

---

## 🔑 Setup Before Publishing

### 1. Stripe Integration (Required for Pro)

**Option A: Stripe Payment Links (Recommended – no backend)**
1. Go to [dashboard.stripe.com/payment-links](https://dashboard.stripe.com/payment-links)
2. Create a new Payment Link → $9.99 → One-time payment
3. In `popup/popup.js` replace:
   ```js
   const STRIPE_PAYMENT_LINK = 'https://buy.stripe.com/YOUR_LINK_HERE';
   ```
4. Set the success URL in Stripe to: `chrome-extension://YOUR_EXTENSION_ID/options/options.html?pro_success=1`

**Option B: Stripe Checkout (Full control)**
1. Create a Price in Stripe dashboard (one-time, $9.99)
2. Deploy a minimal serverless function (Vercel/Netlify):
   ```js
   // api/create-checkout.js
   import Stripe from 'stripe';
   const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
   
   export default async (req, res) => {
     const session = await stripe.checkout.sessions.create({
       payment_method_types: ['card'],
       line_items: [{ price: 'price_XXXXX', quantity: 1 }],
       mode: 'payment',
       success_url: req.body.success_url + '?license={CHECKOUT_SESSION_ID}',
       cancel_url: req.body.cancel_url,
       client_reference_id: req.body.client_id,
     });
     res.json({ url: session.url });
   };
   ```
3. Update `popup.js` to call your endpoint

### 2. Replace Placeholder Keys
In `popup/popup.js` and `options/options.html`:
```js
const STRIPE_PUBLISHABLE_KEY = 'pk_live_YOUR_KEY';
const STRIPE_PAYMENT_LINK    = 'https://buy.stripe.com/YOUR_LINK';
const WEBSTORE_URL = 'https://chrome.google.com/webstore/detail/YOUR_EXT_ID';
```

### 3. Expand Dictionary (Recommended)
Current dictionary: ~1,200 words (demo)
Production: Replace with full 100K word list

**Free word lists:**
- SOWPODS (Scrabble): https://www.wordgamedictionary.com/sowpods/download/sowpods.txt
- ENABLE (WWF-compatible): https://raw.githubusercontent.com/dolph/dictionary/master/enable1.txt
- TWL06 (Tournament): https://www.wordgamedictionary.com/twl06/download/twl06.txt

**Integration:**
```js
// In dictionary/words.js, replace WORD_LIST with:
const WORDS = await fetch(chrome.runtime.getURL('dictionary/words_full.txt'))
  .then(r => r.text())
  .then(t => t.split('\n').map(w => w.trim().toLowerCase()).filter(Boolean));
```
Add `words_full.txt` to `web_accessible_resources` in `manifest.json`.

### 4. Optional: PostHog Analytics
```js
const POSTHOG_KEY = 'phc_YOUR_PROJECT_KEY'; // in popup.js
```

---

## 📁 File Structure

```
scramblesnap/
├── manifest.json           # MV3 manifest
├── assets/
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
├── popup/
│   ├── popup.html          # Main popup UI
│   └── popup.js            # Popup logic + solve engine
├── content/
│   ├── overlay.js          # Floating overlay (injected)
│   └── overlay.css         # Overlay styles
├── background/
│   └── background.js       # Service worker (shortcuts, messages)
├── dictionary/
│   └── words.js            # Dictionary + unscramble engine
├── options/
│   └── options.html        # Settings + Pro activation page
└── README.md
```

---

## 🎮 Game Modes

| Mode | Dictionary | Scoring |
|------|-----------|---------|
| Scrabble | SOWPODS | Standard Scrabble values |
| Wordle | Common 5-letter words | Pattern matching (green/yellow) |
| Words With Friends | ENABLE | WWF tile values |
| Anagram | All words | Length-first sorting |

---

## 🔧 Features by Plan

### Free (Unlimited)
- ✅ Unlimited solves
- ✅ All 4 game modes (no scoring filters)
- ✅ Sort by score, length, A-Z
- ✅ Copy words
- ✅ Basic length filter

### Pro ($9.99 Lifetime)
- ✅ Everything in Free
- ✅ Floating overlay (Ctrl+Shift+S)
- ✅ Starts/ends with filters
- ✅ Must-contain filter
- ✅ No-repeats mode
- ✅ Wildcard (?) support
- ✅ Wordle pattern solver (green/yellow grid)
- ✅ Favorites (⭐)
- ✅ Solve history (last 50)
- ✅ Viral share button
- ✅ Export results

---

## 🏪 Chrome Web Store Submission

### Store Listing Copy

**Name:** ScrambleSnap – Word Unscrambler & Solver

**Short description (132 chars):**
> Instant word unscrambler for Scrabble, Wordle & Words With Friends. Fastest anagram solver & scrabble helper with scoring.

**Full description:**
> ⚡ ScrambleSnap: The fastest word unscrambler and solver for word games.
>
> ✅ SCRABBLE SOLVER: Enter your tiles, get all valid words ranked by Scrabble score. Wildcards (?) supported.
> ✅ WORDLE HELPER: Use the green/yellow pattern grid to find valid guesses from your known letters.
> ✅ WORDS WITH FRIENDS: Full WWF dictionary with WWF scoring.
> ✅ ANAGRAM FINDER: Instantly find all words hidden in any scrambled letters.
>
> 🚀 FASTER THAN WEBSITES: No page loads, no ads. Just paste letters → instant results.
>
> PRO FEATURES ($9.99 once, forever):
> • Floating overlay on ANY webpage (Ctrl+Shift+S)
> • Advanced filters: starts with, ends with, must contain
> • Favorites and solve history
> • One-click viral sharing
>
> Perfect for: Scrabble, Words With Friends, Wordle, Quordle, Anagram puzzles, Bananagrams, crossword solving.

**Category:** Productivity

**Tags:** word unscrambler, solver, scrabble, wordle, words with friends, anagram, word game helper

### Screenshots (1280×800 recommended)
1. Popup showing solve results for "AELPPX" → apple, lap, pal, ale...
2. Scrabble mode with scores shown
3. Wordle pattern grid with green/yellow cells
4. Floating overlay on a webpage
5. Pro upgrade screen

### Privacy Policy Required Fields
- Extension accesses clipboard (optional, for auto-detect)
- No data sent to external servers (offline-first)
- Stripe payment processed by Stripe (not stored locally except Pro status boolean)

---

## 🔒 Security Notes

1. **License validation**: Currently client-side only. For production, validate with your backend:
   ```
   POST /api/validate-license
   { licenseKey, extensionId, timestamp }
   → { valid: true/false, email }
   ```

2. **Stripe webhook**: Set up a webhook to handle `checkout.session.completed` to email license keys

3. **CSP**: manifest.json already has strict CSP. Don't relax it.

---

## 📊 Monetization Strategy

- **Free tier**: Unlimited basic solves → builds user base, drives reviews
- **Pro conversion**: Power users (5+ solves/day) convert at ~3-8%
- **Viral loop**: Share button → "Solved X from Y in ScrambleSnap!" → installs
- **Review prompt**: 5 solves trigger → drives Chrome Store ratings

**Pricing psychology**: $9.99 one-time beats $1.99/month for word game players (occasional use, no subscription guilt)

---

## 🐛 Troubleshooting

**Overlay not showing?**
- Check you have Pro activated
- Verify shortcut isn't conflicting: `chrome://extensions/shortcuts`
- Reload the extension after installing

**Dictionary seems small?**
- Replace `dictionary/words.js` WORD_LIST with full 100K word file (see above)

**Stripe payment not activating Pro?**
- Check the success_url in your Stripe Payment Link settings
- Manually enter license key in Settings → Pro section

---

## 📜 License

ScrambleSnap is proprietary software. Dictionary data may have separate licensing requirements (SOWPODS, ENABLE, TWL are generally free for non-commercial use; verify before publishing commercially).
