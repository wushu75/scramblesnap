// ScrambleSnap Options Page JS
// All logic extracted from options.html inline script (CSP-safe)

const STRIPE_PAYMENT_LINK = 'https://buy.stripe.com/REPLACE_WITH_YOUR_PAYMENT_LINK';
const WEBSTORE_URL = 'https://chrome.google.com/webstore/detail/REPLACE_WITH_YOUR_EXTENSION_ID';

let settings = {};

// ── STORAGE ─────────────────────────────────────────────────────────────────
function storageGet(keys) {
  return new Promise(r => chrome.storage.sync.get(keys, r));
}
function storageSet(obj) {
  return new Promise(r => chrome.storage.sync.set(obj, r));
}

// ── INIT ─────────────────────────────────────────────────────────────────────
async function init() {
  // Check for Stripe success redirect
  const params = new URLSearchParams(window.location.search);
  if (params.get('pro_success') === '1') {
    await activateProFromStripe(params.get('license') || 'stripe_' + Date.now());
    const banner = document.getElementById('success-banner');
    if (banner) banner.style.display = 'flex';
    window.history.replaceState({}, '', window.location.pathname);
  }

  const data = await storageGet(['pro', 'licenseKey', 'proActivatedAt', 'settings', 'solveCount', 'favs', 'solveHistory']);
  settings = data.settings || {};

  updateProUI(data.pro, data.licenseKey, data.proActivatedAt);
  loadStats(data);
  loadSettings();

  // Wire buttons
  document.getElementById('btn-checkout')?.addEventListener('click', goToCheckout);
  document.getElementById('btn-activate-license')?.addEventListener('click', activateLicense);
  document.getElementById('btn-restore-license')?.addEventListener('click', restoreLicense);
  document.getElementById('btn-clear-data')?.addEventListener('click', clearData);
  document.getElementById('btn-feedback-link')?.addEventListener('click', () => openLink('mailto:hello@scramblesnap.io'));
  document.getElementById('btn-privacy-link')?.addEventListener('click', () => openLink('https://scramblesnap.io/privacy'));

  // Auto-save settings on change
  document.querySelectorAll('select, input[type=checkbox]').forEach(el => {
    el.addEventListener('change', saveSettings);
  });
}

// ── PRO UI ───────────────────────────────────────────────────────────────────
function updateProUI(isPro, licenseKey, activatedAt) {
  const badge   = document.getElementById('plan-badge');
  const subText = document.getElementById('pro-sub-text');
  const freeCta = document.getElementById('free-cta');
  const proCta  = document.getElementById('pro-cta');
  const actText = document.getElementById('pro-activated-text');

  if (isPro) {
    if (badge)   { badge.className = 'pro-badge-big'; badge.textContent = 'PRO'; }
    if (subText)   subText.textContent = 'Pro – Lifetime access';
    if (freeCta)   freeCta.style.display = 'none';
    if (proCta)    proCta.style.display = 'block';
    if (actText && activatedAt) actText.textContent = 'Activated: ' + new Date(activatedAt).toLocaleDateString();
  } else {
    if (badge)   { badge.className = 'free-badge-big'; badge.textContent = 'FREE'; }
    if (subText)   subText.textContent = 'Free – basic solving';
    if (freeCta)   freeCta.style.display = 'block';
    if (proCta)    proCta.style.display = 'none';
  }
}

// ── STATS ────────────────────────────────────────────────────────────────────
function loadStats(data) {
  const solves = document.getElementById('stat-solves');
  const words  = document.getElementById('stat-words');
  const favs   = document.getElementById('stat-favs');
  if (solves) solves.textContent = data.solveCount || 0;
  if (words)  words.textContent  = (data.solveHistory || []).reduce((s, h) => s + (h.count || 0), 0);
  if (favs)   favs.textContent   = (data.favs || []).length;
}

// ── SETTINGS ─────────────────────────────────────────────────────────────────
function loadSettings() {
  const modeEl   = document.getElementById('default-mode');
  const sortEl   = document.getElementById('default-sort');
  const autoEl   = document.getElementById('auto-solve');
  const reviewEl = document.getElementById('review-prompt');
  if (modeEl   && settings.defaultMode)                modeEl.value   = settings.defaultMode;
  if (sortEl   && settings.defaultSort)                sortEl.value   = settings.defaultSort;
  if (autoEl   && settings.autoSolve   !== undefined)  autoEl.checked = settings.autoSolve;
  if (reviewEl && settings.reviewPrompt !== undefined)  reviewEl.checked = settings.reviewPrompt;
}

async function saveSettings() {
  settings = {
    defaultMode:  document.getElementById('default-mode')?.value,
    defaultSort:  document.getElementById('default-sort')?.value,
    autoSolve:    document.getElementById('auto-solve')?.checked,
    reviewPrompt: document.getElementById('review-prompt')?.checked,
  };
  await storageSet({ settings });
  showToast('Settings saved');
}

// ── STRIPE / PRO ─────────────────────────────────────────────────────────────
function goToCheckout() {
  const successUrl = chrome.runtime.getURL('options/options.html') + '?pro_success=1';
  chrome.tabs.create({ url: STRIPE_PAYMENT_LINK + '?success_url=' + encodeURIComponent(successUrl) });
}

async function activateLicense() {
  const keyEl = document.getElementById('license-input');
  const key   = keyEl ? keyEl.value.trim() : '';
  if (!key || key.length < 8) { showToast('Please enter a valid license key'); return; }
  if (key.startsWith('SS-') || key.startsWith('stripe_') || key.length >= 16) {
    await activateProFromStripe(key);
    showToast('Pro activated! Enjoy all features.');
    updateProUI(true, key, Date.now());
  } else {
    showToast('Invalid license key. Check your email.');
  }
}

async function activateProFromStripe(licenseKey) {
  await storageSet({ pro: true, licenseKey, proActivatedAt: Date.now() });
}

async function restoreLicense() {
  const key = prompt('Enter your license key to restore:');
  if (key) {
    const keyEl = document.getElementById('license-input');
    if (keyEl) keyEl.value = key;
    await activateLicense();
  }
}

// ── DATA ─────────────────────────────────────────────────────────────────────
async function clearData() {
  if (!confirm('Clear all ScrambleSnap data? (Pro status preserved)')) return;
  const { pro, licenseKey } = await storageGet(['pro', 'licenseKey']);
  await chrome.storage.sync.clear();
  await chrome.storage.local.clear();
  if (pro) await storageSet({ pro, licenseKey });
  showToast('Data cleared');
  setTimeout(() => location.reload(), 1000);
}

function openLink(url) {
  chrome.tabs.create({ url });
}

// ── TOAST ─────────────────────────────────────────────────────────────────────
let toastTimeout;
function showToast(msg) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => el.classList.remove('show'), 2500);
}

// ── BOOT ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', init);
