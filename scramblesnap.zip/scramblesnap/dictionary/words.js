// ScrambleSnap Dictionary
// Production: Replace with full 100K+ word list (enable-list format, ~2MB)
// Sources: SOWPODS (Scrabble), TWL (Tournament Word List), ENABLE (WWF)
// Each entry: [word, scrabble_score, wwf_score]
// Score = sum of letter values; wildcard (?) = 0

const SCRABBLE_VALUES = {
  a:1,b:3,c:3,d:2,e:1,f:4,g:2,h:4,i:1,j:8,k:5,l:1,m:3,
  n:1,o:1,p:3,q:10,r:1,s:1,t:1,u:1,v:4,w:4,x:8,y:4,z:10
};

const WWF_VALUES = {
  a:1,b:4,c:4,d:2,e:1,f:4,g:3,h:3,i:1,j:10,k:5,l:2,m:4,
  n:2,o:1,p:4,q:10,r:1,s:1,t:1,u:2,v:5,w:4,x:8,y:3,z:10
};

// Sample dictionary – 1200 common + game-relevant words
// EXPAND: Load words_full.json (100K) via fetch in production
const WORD_LIST = [
  "aa","ab","ace","aced","aces","ache","acid","acme","acre","act","add","age","ago","aid","aim","air","ale","all","aloe","also","alter","am","amp","and","ant","ape","app","apt","arc","are","ark","arm","art","ash","ask","at","ate","ave","awe","axe","aye",
  "back","bade","bake","bald","bale","ball","band","bane","bang","bank","bar","bare","bark","barn","base","bash","bat","bath","bead","beam","bean","bear","beat","bed","bee","beef","been","beep","beer","beet","bell","belt","best","bid","big","bile","bill","bind","bird","bite","blah","bled","blew","blob","blot","blow","blue","blur","bode","bold","bolt","bond","bone","boo","book","boom","boot","bore","both","bout","bowl","brag","bran","brew","brim","brow","buck","bud","bug","bulk","bull","bun","bunk","burn","burp","bus","but","byte",
  "cab","cage","cake","calf","call","calm","came","camp","cane","cap","cape","card","care","carp","cart","case","cash","cast","cave","cell","cent","chap","char","chat","chef","chin","chip","chop","clam","clap","claw","clay","clod","clog","clop","clot","club","clue","coal","coat","coil","cold","come","cord","core","cork","corn","cost","cozy","crab","crew","crop","crud","cub","cup","cure","curl","cute",
  "dab","daft","dale","dame","damp","dare","dart","data","date","dawn","deal","dean","dear","deck","deed","deep","deny","desk","dial","did","die","dill","dime","dip","dire","disk","dive","dock","dome","dorm","dote","dove","down","drag","draw","drew","drip","drop","drum","dual","dub","dude","duel","dull","dune","dunk","dusk","dust","duty",
  "each","earl","earn","ease","edge","edit","else","emit","epic","even","ever","evil","exam","exit",
  "face","fade","fail","fair","fake","fall","fame","fare","farm","fast","fate","faze","feat","feed","feel","feet","fell","felt","fern","file","fill","find","fire","fish","fist","flap","flat","flaw","fled","flew","flip","flog","flop","flow","foam","folk","fond","font","foot","ford","fore","fork","form","fort","foul","four","fray","free","frog","from","fuel","full","fume","fund","fuse",
  "gale","game","gang","gasp","gate","gave","gear","germ","gift","gill","girl","give","glad","glee","glop","glow","glue","gnat","gnaw","goal","gobs","gold","golf","gone","good","gore","gown","grab","gray","grew","grim","grip","grit","grow","gulf","gush","gust",
  "hack","hail","hair","half","hall","halt","hand","hang","hard","hare","harp","hash","haul","have","hawk","heap","heat","heel","held","helm","help","herb","hide","high","hike","hill","hint","hire","hoax","hole","home","hood","hook","hope","horn","host","hour","howl","hulk","hull","hump","hunt","hurl","hurt","husk",
  "icon","idle","inch","into","iris","isle","item",
  "jade","jape","jaws","jazz","jest","jibe","jolt","judge","jump","just",
  "keen","keep","kelp","kept","kite","knob","knot","know",
  "lack","lake","lamb","lame","lamp","land","lane","lark","lash","last","late","lava","lawn","lead","leaf","leak","lean","leap","left","lend","lens","lest","lift","limb","lime","limp","line","link","lint","lion","lips","list","live","load","loam","lock","loft","lone","long","look","loom","loot","lore","lost","lump","lung","lure","lush","lust",
  "made","mail","main","make","mane","mare","mark","mart","mash","mask","mass","mast","mate","math","maze","meal","mean","meat","melt","memo","mere","mesh","mild","mile","milk","mill","mime","mind","mine","mink","mint","mist","moan","moat","mole","molt","mood","moon","moor","more","most","moth","move","much","mule","mull","musk","must","mute",
  "nail","name","nape","nark","need","nest","newt","next","nice","nifty","nine","node","noel","none","nook","norm","nose","note","nude","numb",
  "oath","obey","odds","ogre","omen","once","open","opus","orca","orge","over","oven","owed","omen","oval",
  "pace","pack","page","pail","pair","pale","palm","pane","park","part","pass","past","path","pave","pawn","peak","pear","peel","peer","pelt","perk","pest","pick","pier","pile","pill","pine","pipe","pith","plan","plod","plot","plow","ploy","plug","plum","plus","poem","poke","pole","poll","pond","pore","port","pose","post","pout","prey","prod","prop","pull","pulp","pump","pure","push",
  "quiz","quip","quit","quod",
  "race","rack","rage","raid","rail","rain","rake","ramp","rank","rare","rash","rate","rave","read","real","reap","reel","rely","rend","rent","rest","rice","rich","ride","rife","rift","ring","riot","ripe","risk","road","roam","roar","robe","rock","rode","role","roll","roof","rope","rose","rote","rout","rowdy","rude","ruin","rule","ruse","rush","rust",
  "safe","sage","sail","sake","sale","salt","same","sand","sane","sang","sap","save","scan","scar","seal","seam","sear","seat","seed","seek","self","sell","sent","shed","ship","shoe","shop","show","shut","sick","sigh","silk","sill","sing","sire","site","size","skew","skip","slag","slam","slap","slat","slay","slew","slim","slip","slob","slop","slur","snap","snob","snot","snow","soak","soap","soar","sock","soil","sole","some","song","soot","sore","sort","soul","span","spar","spin","spit","spot","spud","spur","stab","stag","star","stay","stem","step","stew","stir","stop","stud","suck","suit","sulk","sung","sunk","surf","swam","swap","swat","sway","swim","swot",
  "tack","tail","tale","tame","tang","tape","tare","tarn","tart","task","taut","teal","tear","teed","tell","tend","tent","term","test","that","thaw","them","thin","this","thou","tick","tide","tile","till","time","tine","tire","toad","toil","told","tomb","tone","tong","took","tool","torn","toss","tour","town","trap","trek","trim","trio","trip","trod","troy","true","tuck","tuft","tump","turf","turn","tusk","twin","type",
  "ugly","ulna","unit","upon","urge","used",
  "vale","vane","vary","vase","veil","vein","very","vest","vial","vine","vole","volt","vote",
  "wade","waft","wage","wake","walk","wall","wand","wane","ward","warm","wart","wary","wave","weak","wean","weld","well","welt","went","wept","were","what","when","whim","whip","whit","whom","wile","will","wilt","wink","wire","wise","wish","wisp","with","woke","wolf","womb","wood","wool","word","wore","work","worm","wort","wrap","wren","writ",
  "yank","yarn","yawn","year","yell","yelp","yoke","your","yowl",
  "zeal","zero","zest","zinc","zone","zoom",
  // 5-letter words
  "abase","abate","abbey","abbot","abhor","abide","abler","abode","abort","about","above","abuse","abyss","acids","ached","acres","acted","acute","adage","adapt","adept","adopt","adult","aegis","affix","afoot","after","agate","agile","aglow","agony","agree","ahead","aided","alien","align","alike","alive","allay","allot","allow","aloft","alone","along","aloof","aloud","alpha","altar","ample","amuse","angel","anger","angle","angry","angst","anime","ankle","annex","antic","anvil","aorta","apple","apply","aptly","arbor","ardor","argue","arise","armor","aroma","array","arson","artsy","astra","atone","attic","audio","audit","augur","avail","avant","avert","avian","avid","avoid","awake","award","aware","awful","azure",
  "babel","badger","badge","badly","bagel","baggy","baker","banjo","basic","basis","batch","bathe","bayou","beach","beady","beast","began","begin","being","belle","bench","birch","birth","bison","black","blade","blame","bland","blank","blare","blaze","bleak","bleat","bleed","blend","bless","blimp","blind","blink","bliss","block","blood","bloom","blown","blunt","board","bogus","bonus","brace","braid","brain","brake","brand","brave","brawl","braze","bread","break","breed","brick","bride","brief","brine","bring","brisk","brood","brook","broom","broth","brown","brunt","brush","bumpy","bunch","bunny","buoy","burly","burnt","burst",
  "cabal","cabin","camel","candy","caped","caper","carry","cedar","chaos","charm","chase","cheap","check","cheek","chess","chest","chide","chief","child","chili","chill","china","choir","chord","chunk","civic","civil","clack","claim","clash","class","clean","clear","clerk","click","cliff","cling","clone","close","cloud","clown","coaly","cobra","codon","comet","comic","comma","conga","coral","couch","could","coupe","court","craft","crane","crash","craze","crazy","creak","cream","crest","crimp","crisp","croak","cross","crowd","crown","cruel","crumb","crush","crypt","cubic","curly","curry","curve","cyclo",
  "daily","daisy","dance","dated","dealt","debug","defer","delay","delve","demon","depot","derby","deter","devil","dirty","ditzy","dizzy","dodge","dough","downy","draft","drape","dread","dream","dregs","dress","dried","drift","drive","drove","drool","droop","drove","drown","drove","dunce","dusty","dwarf","dwell","dying",
  "eager","early","earns","earth","eaten","eight","elbow","elect","elite","ember","emote","empower","empty","enemy","enjoy","enter","entry","equip","error","essay","ether","every","exact","exalt","exert","exist","expel","extra",
  "fable","faith","false","fancy","fang","fatal","fault","feast","fence","feud","fewer","fiber","field","fiend","fifty","fight","flair","flake","flame","flare","flash","flask","flung","fly","focus","foggy","force","forge","forth","found","frank","fraud","fresh","front","frost","froze","frugal","fully","fungi","funky","funny","furry","fuzzy",
  "gaudy","gauge","gauze","gavel","gecko","gel","genie","genus","ghost","giddy","given","gland","glare","glass","glint","gloom","glory","gloss","glove","going","golly","gorge","gouge","gourd","grace","grade","grain","grand","grant","grape","grasp","gravel","graze","greed","green","greet","grief","grill","grind","groan","groom","grope","gross","grout","grove","growl","gruel","gruff","grunt","guile","gusto","gutsy",
  "habit","happy","harsh","haste","haven","havoc","hazel","heavy","hedge","hefty","hence","heron","hippo","hitch","hoard","hobby","holly","honey","honor","horse","hotel","house","haste","humph","humor","husky",
  "ideal","image","imply","inane","inert","infer","infix","input","inter","intro","inure","ivory",
  "jaunt","jewel","jiffy","jolly","joust","juice","juicy","jumbo","jumpy",
  "kazoo","kneel","knife","knock","knave","kneel",
  "label","lance","lanky","lapel","lasso","latch","later","laugh","layer","leaky","learn","ledge","legal","leaky","lemon","level","light","linen","liver","llama","lodge","logic","loopy","lorry","lousy","lucid","lucky","lusty",
  "magic","major","maker","manor","maple","match","maxim","mealy","media","meldy","melee","mercy","merit","messy","metal","meter","might","minor","minus","mirth","miser","model","money","moody","moose","moral","mossy","motif","mound","mourn","mouth","murky","musty",
  "naive","nasty","naval","nervy","newly","night","ninja","noble","noise","north","nutty",
  "occur","ocean","offer","often","olive","omit","onion","onset","oozed","opted","orbit","order","other","outer","ovary","oxide",
  "paddy","paint","panic","pansy","papal","parse","party","pasta","pasty","patsy","pause","peace","penny","petty","phase","phone","photo","piano","picky","piney","pixel","pizza","place","plaid","plain","plane","plant","plank","plaza","plead","pleat","plonk","pluck","plume","plunk","plush","point","pointy","polka","poppy","porch","posed","posse","pouty","power","prank","press","price","prick","pride","prime","primp","print","prior","prize","probe","prove","prowl","proxy","pudgy","pulse","punchy","pupil","purse","pussy","putty","pygmy",
  "queen","query","queue","quick","quiet","quirk","quota","quote",
  "rainy","rally","raven","reach","ready","realm","recap","relax","repay","repel","rerun","reset","reuse","revel","rhyme","rider","ridge","risky","rivet","robot","rocky","rouge","rough","round","rowdy","royal","rugby","ruler","rusty",
  "sadly","saint","sandy","sauce","saucy","savvy","scald","scale","scalp","scaly","scamp","scant","scone","scoop","scoot","scope","scorn","scour","scout","scowl","scram","scrap","scrub","seedy","sense","serif","serve","setup","seven","sever","shack","shade","shady","shaft","shake","shaky","shale","shall","shame","shape","share","sharp","shear","sheen","shelf","shell","shift","shine","shiny","shirt","shove","shrine","shown","siege","sight","silly","silky","since","sixth","sixty","skate","skill","skimp","skulk","skull","slant","slash","slate","slave","sleek","sleep","sleet","slept","slice","slide","slime","slimy","slink","slope","smart","smash","smear","smell","smile","smirk","smoke","snack","snake","snare","sneak","sniff","snore","snort","solar","solve","spare","spark","spawn","spear","speed","spell","spend","spice","spied","spike","spiky","spill","spine","spite","splat","split","spoke","spoof","spook","spoon","spore","sport","spout","spray","spread","spree","squat","squeak","squeal","squid","stack","staff","stain","stake","stale","stall","stamp","stank","stark","start","state","stave","steel","steer","stern","stick","stiff","still","sting","stock","stomp","stood","stoop","store","storm","story","stout","stove","stray","strew","strip","stump","stung","stunt","style","suave","sugar","suite","sunny","super","surge","sushi","swear","sweat","sweep","sweet","swept","swift","swipe","swirl",
  "tabby","table","taffy","tapir","tardy","taste","tasty","taunt","tawny","tempt","tense","tepid","terse","thank","their","theme","there","thick","thing","think","thorn","three","threw","throw","thumb","tiara","tidal","tiger","tight","tired","today","token","tonic","total","touch","tough","towel","toxic","track","trade","train","tramp","trawl","tread","treat","trend","trial","tribe","trick","tried","troop","trout","truce","trump","trunk","tryst","tulip","tumor","tuner","turbo","twang","tweak","tweed","twice","twirl","twist","twitch",
  "ultra","uncut","under","undue","union","unkempt","unlit","unzip","upper","upset","urban","usher","utter",
  "vague","valid","valor","value","valve","video","vigor","viral","vital","vicar","viper","vixen","voice","voila","vying",
  "wagon","water","weary","weave","wedge","weedy","weird","whale","wheat","wheel","where","which","while","white","whole","widen","wield","wimpy","windy","witch","witty","wizen","woman","women","wonky","world","wordy","worst","worth","would","wreak","wreck","wring","wrist","wrong","wrote",
  "yacht","yearn","yield","young","youth","yucky","yummy",
  "zebra","zilch","zippy","zonal",
  // 6+ letter words  
  "abandon","ability","aboard","absorb","abstract","abundant","accent","accept","access","accomplish","accord","account","accuse","achieve","acquire","active","actual","adhere","adjust","admire","advance","afford","against","agency","agenda","almost","already","always","amaze","amount","animal","answer","antler","appear","around","arrive","artful","artist","aspect","assure","attach","attack","author","avenue",
  "battle","better","beyond","binder","blanket","blister","blossom","border","bottle","bottom","breach","bridge","bright","broken","brother","burden","button",
  "cancer","candle","canvas","carbon","castle","cattle","center","chance","change","charge","choose","circle","circus","clever","client","clover","cobalt","coffee","column","combat","comfort","common","compete","corner","cotton","couple","credit","crisis","crystal","custom",
  "danger","debate","decide","define","delete","deliver","design","detail","device","direct","doctor","double","dragon","drawer","during",
  "easily","effect","either","employ","enable","entire","escape","evolve","except","expect","extend","extreme",
  "fabric","factor","family","famous","faster","father","figure","finger","finish","flower","follow","forest","formal","former","foster","foster","freedom","friend","future",
  "garage","garden","gather","gentle","global","ground","should","silver","single","sister","slowly","smooth","social","special","spirit","spoken","spring","square","stable","strict","strong","struck","summer","supply","surely","system",
  "little","lively","lonely","longer","lovely","lowest","lumber","marble","market","master","matter","middle","mirror","misery","mobile","moment","mostly","mother","motion","muscle",
  "nature","nearly","notice","number","online","orange","origin","other",
  "parent","people","person","pillar","planet","please","pledge","pocket","police","portal","pretty","prince","prison","profit","public","purple",
  "rabbit","radius","random","rather","really","reason","record","reduce","region","repair","repeat","rescue","resist","result","return","reveal","reward","rocket",
  "safety","sample","school","screen","secret","select","settle","shadow","simple","window","wonder","worthy","writer",
  "talent","target","temple","tennis","theory","though","threat","timber","tongue","travel","tribal","triple","trophy","tunnel","turtle",
  "unhappy","unique","unless","unusual","update","useful","valley","vanish","vessel","victim","vision","volume",
  "walker","wander","wealth","weapon","weather","weekly","western","window","wisdom","wonder","wooden","worker","worsen","worthy"
];

// Deduplicate and sort
const WORDS = [...new Set(WORD_LIST.map(w => w.toLowerCase()))].sort();

function getScrabbleScore(word, game = 'scrabble') {
  const vals = game === 'wwf' ? WWF_VALUES : SCRABBLE_VALUES;
  return word.toLowerCase().split('').reduce((sum, c) => sum + (vals[c] || 0), 0);
}

function unscramble(letters, options = {}) {
  const {
    game = 'scrabble',
    minLength = 2,
    maxLength = letters.replace(/\?/g, 'a').length,
    startsWith = '',
    endsWith = '',
    mustContain = '',
    noRepeats = false,
    exactLength = null,
    wordlePattern = null, // e.g. {greens: {0:'s',2:'a'}, yellows: {e:[1]}}
  } = options;

  const cleanLetters = letters.toLowerCase().replace(/[^a-z?]/g, '');
  const letterArr = cleanLetters.split('');
  const wildcardCount = letterArr.filter(c => c === '?').length;
  const normalLetters = letterArr.filter(c => c !== '?');

  const results = [];

  for (const word of WORDS) {
    const len = word.length;
    if (len < minLength) continue;
    if (exactLength && len !== exactLength) continue;
    if (len > maxLength) continue;
    if (startsWith && !word.startsWith(startsWith.toLowerCase())) continue;
    if (endsWith && !word.endsWith(endsWith.toLowerCase())) continue;
    if (mustContain && !word.includes(mustContain.toLowerCase())) continue;

    // Wordle mode filter
    if (wordlePattern) {
      if (len !== 5) continue;
      let valid = true;
      const { greens = {}, yellows = {} } = wordlePattern;
      for (const [pos, letter] of Object.entries(greens)) {
        if (word[parseInt(pos)] !== letter) { valid = false; break; }
      }
      if (!valid) continue;
      for (const [letter, badPositions] of Object.entries(yellows)) {
        if (!word.includes(letter)) { valid = false; break; }
        for (const pos of badPositions) {
          if (word[parseInt(pos)] === letter) { valid = false; break; }
        }
        if (!valid) break;
      }
      if (!valid) continue;
    }

    // Check if word can be formed from available letters
    const available = [...normalLetters];
    let wildcardsUsed = 0;
    let canForm = true;

    for (const c of word) {
      const idx = available.indexOf(c);
      if (idx !== -1) {
        available.splice(idx, 1);
      } else if (wildcardsUsed < wildcardCount) {
        wildcardsUsed++;
      } else {
        canForm = false;
        break;
      }
    }

    if (!canForm) continue;

    // noRepeats filter
    if (noRepeats) {
      const seen = new Set();
      let hasRepeat = false;
      for (const c of word) {
        if (seen.has(c)) { hasRepeat = true; break; }
        seen.add(c);
      }
      if (hasRepeat) continue;
    }

    const score = getScrabbleScore(word, game);
    results.push({ word, score, length: len, wildsUsed: wildcardsUsed });
  }

  // Sort: by score desc, then length desc
  results.sort((a, b) => b.score - a.score || b.length - a.length);
  return results;
}

// Export for both module and non-module contexts
if (typeof module !== 'undefined') {
  module.exports = { WORDS, unscramble, getScrabbleScore, SCRABBLE_VALUES, WWF_VALUES };
}
